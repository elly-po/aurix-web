```markdown
# Project Overview
- **Project**: Aurix - A website for a meme coin.
- **Tech Stack**: 
- **Environment**: 

# Theme, Style, and Vibe
- **Theme**: Modern, crypto-focused
- **Style**: Fun/meme culture with professionalism
- **Vibe**: Engaging and community-oriented

# Conversation Context
- **Last Topic**: 
- **Key Decisions**: 
- **User Context**:
  - Technical Level: 
  - Preferences: 
  - Communication: 

# Implementation Status
## Current State
- **Active Feature**: 
- **Progress**: 
- **Blockers**: 

## Code Evolution
- **Recent Changes**: 

# Requirements
- **Implemented**: 
- **In Progress**: 
- **Pending**: Typical meme coin website elements like tokenomics, roadmap, community links, etc.
- **Technical Constraints**: 

# Critical Memory
- **Must Preserve**: 
- **User Requirements**: 
- **Known Issues**: 

# Next Actions
- **Immediate**: 
- **Future**: 
```